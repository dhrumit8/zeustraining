import { Component } from '@angular/core';
import { ProgressService } from 'src/app/services/current-step.service';

@Component({
  selector: 'app-registration-header',
  templateUrl: './registration-header.component.html',
  styleUrls: ['./registration-header.component.scss']
})
export class RegistrationHeaderComponent {
  constructor (private progressService: ProgressService){

  }
  stepIndex = 2;
  ngOnInit(): void {
    this.progressService.currentStepIndex$.subscribe(index => {
      this.stepIndex = index;
    });
  }
}
