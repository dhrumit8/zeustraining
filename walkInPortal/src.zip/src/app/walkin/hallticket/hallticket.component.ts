import { Component } from '@angular/core';

@Component({
  selector: 'app-hallticket',
  templateUrl: './hallticket.component.html',
  styleUrls: ['./hallticket.component.scss']
})
export class HallticketComponent {

}
