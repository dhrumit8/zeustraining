import { Component } from '@angular/core';

@Component({
  selector: 'app-job-roles-card',
  standalone: true,
  imports: [],
  templateUrl: './job-roles-card.component.html',
  styleUrls: ['./job-roles-card.component.scss']
})
export class JobRolesCardComponent {

}
