import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { JobRoles } from 'src/app/interfaces/interfaces';
import { DataSharingService } from 'src/app/services/data-sharing.service';

@Component({
  selector: 'app-walkin-job-roles',
  templateUrl: './walkin-job-roles.component.html',
  styleUrls: ['./walkin-job-roles.component.scss']
})
export class WalkinJobRolesComponent {
  jobs : JobRoles[] = [
    {
      title: 'WalkIn for Designer Job Role',
      expires: 5,
      startDate: '10-Jul-2021',
      endDate: '11-Jul-2021',
      location: 'Mumbai',
      industrialDesigner: true,
      softwareEngineer: false,
      softwareQualityEngineer: false,
      opportunity: null,
    },
    {
      title: 'WalkIn for Multiple Job Roles',
      expires: null,
      startDate: '03-Jul-2021',
      endDate: '03-Jul-2021',
      location: 'Mumbai',
      industrialDesigner: true,
      softwareEngineer: true,
      softwareQualityEngineer: true,
      opportunity: 'Internship Opportunity for MCA Students',
    },
    {
      title: 'WalkIn for Software Roles',
      expires: null,
      startDate: '10-Jul-2021',
      endDate: '11-Jul-2021',
      location: 'Mumbai',
      industrialDesigner: true,
      softwareEngineer: true,
      softwareQualityEngineer: false,
      opportunity: null,
    },

  ]

  constructor(private dataService: DataSharingService) {}

  viewDetails(job: JobRoles){
    this.dataService.setSelectedItem(job);
  }
}
