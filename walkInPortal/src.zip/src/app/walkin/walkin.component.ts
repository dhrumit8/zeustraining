import { Component } from '@angular/core';

@Component({
  selector: 'app-walkin',
  templateUrl: './walkin.component.html',
  styleUrls: ['./walkin.component.scss']
})
export class WalkinComponent {

}
